package application;

public class Human extends Player {

	private String armor = "";
	private String lightWeapon = "";
	
	Human(String name, int age, char gender, String weapon, String armor) {
		super(name, age, gender);
		this.lightWeapon = weapon;
		this.armor = armor;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void setWeapon() {
		// TODO Auto-generated method stub
		
	}
	
	public String getWeapon() {
		return lightWeapon;
	}
	
	public void setArmor(String armor) {
		this.armor = armor;
	}
	
	public String getArmor() {
		return armor;
	}
	
	public String toString() {
		//return("Name: " + name + "\nAge: " + age + "\nGender: " + gender);
		return(super.toString() + "\n" + "Light Weapon: " + lightWeapon + "\n" + "Armor: " + armor);
	}
}

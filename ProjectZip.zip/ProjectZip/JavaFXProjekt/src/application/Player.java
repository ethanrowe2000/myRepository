package application;

public abstract class Player {

	protected String name = "";
	protected int age = 0;
	protected char gender = 'M';
	
	Player(String name, int age, char gender){
		this.name = name;
		this.age = age;
		this.gender = gender;	
	}
	
	//setters
	public void setName(String name) {
		this.name = name;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setName(char gender) {
		this.gender = gender;
	}
	//getters
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public char getGender() {
		return gender;
	}
	
	public String toString() {
		return("Name: " + name + "\nAge: " + age + "\nGender: " + gender);
	}

	abstract void setWeapon();
	abstract String getWeapon();
	};
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


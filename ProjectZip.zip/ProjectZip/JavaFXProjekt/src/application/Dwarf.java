package application;

public class Dwarf extends Player {

	private String armor, heavyWeapon;
	
	Dwarf(String name, int age, char gender, String armor, String heavyWeapon) {
		super(name, age, gender);
		this.armor = armor;
		this.heavyWeapon = heavyWeapon;
		
		// TODO Auto-generated constructor stub
	}

	@Override
	void setWeapon() {
		// TODO Auto-generated method stub
		
	}
	public String getWeapon() {
		return heavyWeapon;
	}
	public void setHeavyArmor(String armor) {
		this.armor = armor;
	}
	
	public String getHeavyArmor() {
		return armor;
	}
	
	public String toString() {
		//return("Name: " + name + "\nAge: " + age + "\nGender: " + gender);
		return(super.toString() + "\n" + "Heavy Armor: " + armor + "\n");
	}
}

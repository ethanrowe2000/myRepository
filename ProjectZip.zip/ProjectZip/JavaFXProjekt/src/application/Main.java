package application;

import javafx.application.Application;
import javafx.scene.layout.GridPane;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import java.io.File;
import java.util.Scanner;
import EnemyPackage.Spider;
import EnemyPackage.Troll;
import EnemyPackage.Wyvern;

import RandomNumGen.*;

public class Main extends Application {
	//Here are the buttons that will be used to configure the play through. 
	Button human = new Button("Human");
	Button elf = new Button("Elf");
	Button dwarf = new Button("Dwarf");
	Label label = new Label("Please select which character you wish to play as:\n ");
	Player thePlayer;//reference, which will later store the main character. 
	String s = "";
	final int enemySelect = RandomNumGen.randomNum(s);
	
	String para1 = "", para2 = "";
	@Override
	public void start(Stage primaryStage) {
		
		try {
			
			//This is what the buttons and text will display on.
			GridPane pane = new GridPane();
			//set the alignment of the pane.
			pane.setAlignment(Pos.CENTER);
			
			//access text from a couple of files.
			File file = new File("C:\\Users\\willi\\eclipse-workspace\\JavaFXProjekt\\src\\application\\Para1.txt");
			Scanner input = new Scanner(file);
			while(input.hasNextLine()) {
				para1 += input.nextLine();
			}

			Label label2 = new Label(para1);//formats the text in first paragraph to look more center and show on more than one line!
			label2.setPrefWidth(400);
			label2.setWrapText(true);
			
			//access text from a couple of files.
			File file2 = new File("C:\\Users\\willi\\eclipse-workspace\\JavaFXProjekt\\src\\application\\Para2.txt");
			Scanner input2 = new Scanner(file2);
			while(input2.hasNextLine()) {
				para2 += input2.nextLine();
			}

			Label label3 = new Label(para2);//formats the text in first paragraph to look more center and show on more than one line!
			label3.setPrefWidth(400);
			label3.setWrapText(true);
			
			
			//These next few lanes will insert the buttons to select the character race
			pane.add(label2, 0, 0);
			pane.add(new Label(""), 0, 1);
			pane.add(label3, 0, 2);
			pane.add(new Label(""), 0, 3);
			pane.add(label, 0, 4);
			pane.add(human, 0, 5 );
			pane.add(dwarf, 0, 6);
			pane.add(elf, 0, 7);
			
			//these set on actions trigger the player instance to be created and scene2 to play based on whatever button they clicked on. 
			
			human.setOnAction(e->{ hideRaceMenu(); playerInfo(primaryStage, 1);});
			dwarf.setOnAction(e->{ hideRaceMenu(); playerInfo(primaryStage, 2);});
			elf.setOnAction(e->{ hideRaceMenu(); playerInfo(primaryStage, 3);});
			
			//sets the alignment of the button after they have been added to the scene.
			GridPane.setHalignment(label, HPos.CENTER);
			GridPane.setHalignment(label2, HPos.CENTER);
			GridPane.setHalignment(label3, HPos.CENTER);
			GridPane.setHalignment(human, HPos.CENTER);
			GridPane.setHalignment(dwarf, HPos.CENTER);
			GridPane.setHalignment(elf, HPos.CENTER);
			//Here is the scene that will hold the info.
			Scene scene1 = new Scene(pane,500,400);
			//sets title and scene in stage and shows it. 
			primaryStage.setTitle("Merit Trials");
			primaryStage.setScene(scene1);
			primaryStage.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void hideRaceMenu() {//this function hides the buttons when the user clicks on any of the three. 
		human.setVisible(false);
		dwarf.setVisible(false);
		elf.setVisible(false);
	}
	
	public void playerInfo(Stage primaryStage, int selection){//this method creates the next scene in the app. 
		Label nameLabel = new Label("Name:");//labels
		Label ageLabel = new Label("Age:");
		Label genderLabel = new Label("Male or Female:");
		Label weaponLabel = new Label("Weapon:");
		Label armorLabel = new Label("Armor");
		Button enter = new Button("Enter");
		
		TextField name = new TextField();//here are the text fields for the user to input the character info.
		TextField age = new TextField();
		TextField gender = new TextField();
		TextField weapon = new TextField();
		TextField armor = new TextField();
		
		//creates a new pane for and scene for the passed primary stage to display after user picks race. 
		GridPane pane2 = new GridPane();
		pane2.setAlignment(Pos.CENTER);
		//add all the text fields and labels to the pane:
		
		pane2.add(nameLabel, 0, 0);//add all the labels and text fields to the second scene. 
		pane2.add(name, 1, 0);
		pane2.add(ageLabel, 0, 1);
		pane2.add(age, 1, 1);
		pane2.add(genderLabel, 0, 2);
		pane2.add(gender, 1, 2);
		pane2.add(weaponLabel, 0, 3);
		pane2.add(weapon, 1, 3);
		pane2.add(armorLabel, 0, 4);
		pane2.add(armor, 1, 4);
		pane2.add(enter, 0,5);
		pane2.add(new Label("NOTE: If Enter isn't working, make sure for gender you have entered either a M or F only. "), 0, 6);
		
		Scene scene2 = new Scene(pane2, 800, 200);//creates the scene and the size of the scene.
		primaryStage.setScene(scene2);//sets it in the application
		primaryStage.show();//shows the scene in the application. 
		
			enter.setOnAction(e->{//This enter button will create the player, and trigger the short story. 
				
				try {	//this try catch will redo the input screen for player info if an error is thrown within this try block. 
					String nameInput = name.getText();//getting data from text fields from the application screen and storing in variables. 
					int ageInput = Integer.parseInt(age.getText());
					char genderInput = gender.getText().charAt(0);
					String weaponInput = weapon.getText();
					String armorInput = armor.getText();
					
					createObject(selection, nameInput, ageInput, genderInput, weaponInput, armorInput);
					pane2.setVisible(false);
					startGame(primaryStage);//triggers next part of the app. 
					
				}catch(Exception ex) {
					System.out.println("Exception caught. ");//just for following along in the console in eclipse. 
					playerInfo(primaryStage, selection);
				}
			});//passes this data to another method to create player instance
		}
	
	public void createObject(int selection, String nameInput, int ageInput, char genderInput, String weaponInput, String armorInput ){

		if(selection == 1) {// of else statements create the player instance based on selection of race. human, dwarf, elf.
			thePlayer = new Human(nameInput, ageInput, genderInput, weaponInput, armorInput);
			 System.out.println(thePlayer.toString());
		}
		else if(selection == 2) {
			thePlayer = new Dwarf(nameInput, ageInput, genderInput, weaponInput, armorInput);
			System.out.println(thePlayer.toString());
		}
		else {
			thePlayer = new Elf(nameInput, ageInput, genderInput, weaponInput, armorInput);
			System.out.println(thePlayer.toString());
		}	
	}

	public void startGame(Stage primaryStage) {//game begins. 
		//here is the makings of the next pane to go in another scene, on the original stage. 
		Button next = new Button("Next");
		GridPane.setHalignment(next, HPos.RIGHT);//sets location of the button 
		String para3 = "";
		Label label2 = new Label();
		try {
			File file = new File("C:\\Users\\willi\\eclipse-workspace\\JavaFXProjekt\\src\\application\\Para3.txt");
			Scanner input = new Scanner(file);
			while(input.hasNextLine()) {
				para3 += input.nextLine();
			}

			label2 = new Label(para3);//formats the text in first paragraph to look more center and show on more than one line!
			label2.setPrefWidth(400);
			label2.setWrapText(true);
			
		}catch(Exception e ) {
			
		}
		
		GridPane pane3 = new GridPane();
		pane3.setAlignment(Pos.CENTER);
		
		pane3.add(label2, 0, 0);
		pane3.add(new Label(""), 0, 1);
		pane3.add(next, 0, 2);//adds the button and text field to the pane. 
		
		Scene scene3 = new Scene(pane3, 500, 500);//adds the updated third pane to the scene. 
		primaryStage.setScene(scene3);//places the scene on the stage, and then displays it on the next line of code. 
		primaryStage.show();
			
		next.setOnAction(e->{ pane3.setVisible(false); fight(primaryStage);});//this hides the third created pane and starts the next method. 
		
	}
	
	public void fight(Stage primaryStage) {
		
		Button fight = new Button("FIGHT!");
		
		GridPane pane4 = new GridPane();
		GridPane.setHalignment(fight, HPos.CENTER);
		GridPane.setHalignment(pane4, HPos.CENTER);
		
		pane4.add(new Label("You land in the ring. There is a towering creature lurking in front of you. It is a " + createAndFight() + "!"), 0, 0);
		
		pane4.add(fight, 0, 5);
		
		fight.setOnAction(e -> {     
			if(enemySelect == 1) {fightSpider(pane4);}
			else if(enemySelect == 2) {fightTroll(pane4);}
			else {fightWyvern(pane4);}
		});
		Scene scene4 = new Scene(pane4, 600, 600);
		pane4.setAlignment(Pos.CENTER);
		primaryStage.setScene(scene4);
		primaryStage.show();
	}
	
	public String createAndFight() {//creates instances of enemy. 
		
		String s = ""; 
		int eHealth = 50;//variables that set a health for the enemy.
		
		if(enemySelect == 1) {//creates the enemy instance. 
			Spider theEnemy = new Spider(eHealth);
			return theEnemy.getName();
		}else if(enemySelect == 2) {
			Troll theEnemy = new Troll(eHealth);
			return theEnemy.getName();
		}
		else {	
			 Wyvern theEnemy = new Wyvern(eHealth);
			 return theEnemy.getName();
		}
	};
	
	//these methods add text depending on what instance of enemy was created. 
	public void fightSpider(GridPane pane4) {
		pane4.add(new Label("The Spider crawls towards you!"), 0, 1);
		pane4.add(new Label("TO BE CONTINUED..."),0,2);
		GridPane.setHalignment(pane4, HPos.CENTER);
	};
	public void fightTroll(GridPane pane4) {
		pane4.add(new Label("The Troll swings his club!"), 0, 1);
		GridPane.setHalignment(pane4, HPos.CENTER);
		pane4.add(new Label("TO BE CONTINUED..."),0,2);
	};
	public void fightWyvern(GridPane pane4) {
		pane4.add(new Label("The Wyvern breathes fire!"), 0, 1);
		GridPane.setHalignment(pane4, HPos.CENTER);
		pane4.add(new Label("TO BE CONTINUED..."),0,2);
	};
	
	public static void main(String[] args) {
		launch(args);
	}
}

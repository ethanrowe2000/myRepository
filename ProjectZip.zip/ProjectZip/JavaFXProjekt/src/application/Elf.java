package application;

public class Elf extends Player {

	private String armor, rangedWeapon;
	
	Elf(String name, int age, char gender, String armor, String rangedWeapon) {
		super(name, age, gender);
		this.armor = armor;
		this.rangedWeapon = rangedWeapon;
		
		// TODO Auto-generated constructor stub
	}

	@Override
	void setWeapon() {
		// TODO Auto-generated method stub
		
	}
	public String getWeapon() {
		return rangedWeapon;
	}
	
	public void setLightArmor(String armor) {
		this.armor = armor;
	}
	
	public String getLightArmor() {
		return armor;
	}
	
	public String toString() {
		//return("Name: " + name + "\nAge: " + age + "\nGender: " + gender);
		return(super.toString() + "\n" + "Light Armor: " + armor + "\n" +"Ranged Weapon: " + rangedWeapon);
	}
}

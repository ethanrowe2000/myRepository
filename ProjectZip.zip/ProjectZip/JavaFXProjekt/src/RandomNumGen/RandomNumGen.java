package RandomNumGen;
import java.util.Random;

public class RandomNumGen {
	
	public static int randomNum(String s) {
		
		Random random = new Random();
		System.out.println(random);
		return (random.nextInt(3)+1);//produces 1-5
	}
	public static int randomNum(){
		int damage;
		 Random random = new Random();
		 damage = (random.nextInt(40) +1);
		 return damage;
	}
}

package EnemyPackage;

import RandomNumGen.RandomNumGen;

public class Troll extends Enemy{

	private int bluntDamage;
	private String name = "Troll";
	public Troll(int health) {
		super(health);
		// TODO Auto-generated constructor stub
	}

	public String getName(){
		return name;
	}
	
	@Override
	public void specialAttack() {
		//code to generate some amount of blunt trauma attack amount.
		bluntDamage = RandomNumGen.randomNum() + 6;
	}

}

package EnemyPackage;
import RandomNumGen.*;

public abstract class Enemy {
	protected int health, attackAmount, randomNum;
	
	//constructor
	Enemy(int health){
		this.health = health;
	}
	
	public void setHealth(int health) {
		this.health = health;
	}

	public int getHealth() {
		return health;
	}
	
	//the next two are methods for different attacks on the player.
	public int lightAttack() {
		//some coding here to determine the attack amount.
		return attackAmount;
	}
	
	public int HeavyAttack() {
		//some coding here to determine the attack amount.
		return attackAmount;
	}
	
	public int genRandomNum(){// child classes will use this to make some calculations on attacking. 
		String s="";
		return RandomNumGen.randomNum(s);
	}
	
	
	public abstract void specialAttack();
}

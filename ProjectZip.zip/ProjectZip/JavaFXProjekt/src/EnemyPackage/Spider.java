package EnemyPackage;

import RandomNumGen.RandomNumGen;

public class Spider extends Enemy {
	
	private int poisonDamage;
	private String name = "Arachnid";
	
	public Spider(int health){
		super(health);
	}
	
	public String getName(){
		return name;
	}

	@Override
	public void specialAttack() {
		//code to generate some amount of poison attack amount.
		
		poisonDamage = RandomNumGen.randomNum() + 3;
	};
}

package EnemyPackage;

import RandomNumGen.RandomNumGen;

public class Wyvern extends Enemy {

	private int fireDamage;
	private String name =  "Wyvern";
	
	public Wyvern(int health) {
		super(health);
		// TODO Auto-generated constructor stub
	}

	public String getName(){
		return name;
	}
	
	@Override
	public void specialAttack() {
		//code to generate some amount of fire attack amount.
		fireDamage = RandomNumGen.randomNum() + 10;
	}

}
